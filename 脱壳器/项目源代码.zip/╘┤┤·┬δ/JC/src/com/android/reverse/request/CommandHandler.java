package com.android.reverse.request;

public interface CommandHandler {	

	public abstract void doAction();
	
}
