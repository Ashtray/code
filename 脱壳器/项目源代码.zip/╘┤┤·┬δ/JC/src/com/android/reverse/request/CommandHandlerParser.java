package com.android.reverse.request;

import org.json.JSONException;
import org.json.JSONObject;

import com.android.reverse.util.Logger;

public class CommandHandlerParser {

	private static String ACTION_NAME_KEY = "action";
	private static String ACTION_DUMP_DEXINFO = "dexinfo";
	private static String ACTION_DUMP_DEXFILE = "dexfile";
	private static String PARAM_DEXPATH_DUMP_DEXFILE = "dexpath";

	public static CommandHandler parserCommand(String cmd) {
		CommandHandler handler = null;
		try {
			JSONObject jsoncmd = new JSONObject(cmd);
			String action = jsoncmd.getString(ACTION_NAME_KEY);
			Logger.log("cmd is " + action);
			if (ACTION_DUMP_DEXINFO.equals(action)) {
				handler = new DumpDexInfoCommandHandler();
			} else if (ACTION_DUMP_DEXFILE.equals(action)) {
				if (jsoncmd.has(PARAM_DEXPATH_DUMP_DEXFILE)) {
					String dexpath = jsoncmd.getString(PARAM_DEXPATH_DUMP_DEXFILE);
					handler = new DumpDexFileCommandHandler(dexpath);
				} else {
					Logger.log("please input the " + PARAM_DEXPATH_DUMP_DEXFILE);
				}
			} else {
				Logger.log(action + " cmd is wrong! ");
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return handler;
	}

}
