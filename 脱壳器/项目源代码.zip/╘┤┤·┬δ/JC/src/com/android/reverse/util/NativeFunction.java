package com.android.reverse.util;

import java.nio.ByteBuffer;

public class NativeFunction{
	
	private final static String DVMNATIVE_LIB = "/data/data/com.android.reverse/lib/libdvmnative.so";
	
	static{
		System.load(DVMNATIVE_LIB);
	}	

	public static native ByteBuffer dumpDexFileByCookie(int cookie,int version);

}
