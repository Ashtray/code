#include <string.h>
#include <jni.h>
#include <dlfcn.h>
#include <pthread.h>
#include <stdint.h>
#include "util.h"
#include "elfinfo.h"

#define DEX_MAGIC       "dex\n"
#define DEX_MAGIC_VERS  "036\0"
#define DEX_MAGIC_VERS_API_13  "035\0"
#define DEX_OPT_MAGIC   "dey\n"
#define DEX_OPT_MAGIC_VERS  "036\0"
#define DEX_DEP_MAGIC   "deps"

typedef void* (*dvmDecodeIndirectRef_func)(void* self, jobject jobj);
typedef void* (*dvmThreadSelf_func)();
typedef int (*dvmGetInlineOpsTableLengthPtr)();
void* (*dvmDecodeIndirectRef_ptr)(void* self, jobject jobj);
void* (*dvmThreadSelf_ptr)();

typedef struct DexHeader {
    u1 magic[8];           /* includes version number */
    u4  checksum;           /* adler32 checksum */
    u1 signature[20];      /* SHA-1 hash */
    u4  fileSize;           /* length of entire file */
    u4  headerSize;         /* offset to start of next section */
    u4  endianTag;
    u4  linkSize;
    u4  linkOff;
    u4  mapOff;
    u4  stringIdsSize;
    u4  stringIdsOff;
    u4  typeIdsSize;
    u4  typeIdsOff;
    u4  protoIdsSize;
    u4  protoIdsOff;
    u4  fieldIdsSize;
    u4  fieldIdsOff;
    u4  methodIdsSize;
    u4  methodIdsOff;
    u4  classDefsSize;
    u4  classDefsOff;
    u4  dataSize;
    u4  dataOff;
}DexHeader;

typedef struct DexOptHeader {
    u1  magic[8];           /* includes version number */

    u4  dexOffset;          /* file offset of DEX header */
    u4  dexLength;
    u4  depsOffset;         /* offset of optimized DEX dependency table */
    u4  depsLength;
    u4  optOffset;          /* file offset of optimized data tables */
    u4  optLength;

    u4  flags;              /* some info flags */
    u4  checksum;           /* adler32 checksum covering deps/opt */

    /* pad for 64-bit alignment if necessary */
}DexOptHeader;

/*
 * Direct-mapped "map_item".
 */
typedef struct DexMapItem {
    u2 type;              /* type code (see kDexType* above) */
    u2 unused;
    u4 size;              /* count of items of the indicated type */
    u4 offset;            /* file offset to the start of data */
}DexMapItem;

/*
 * Direct-mapped "map_list".
 */
typedef struct DexMapList {
    u4  size;               /* #of entries in list */
    DexMapItem list[1];     /* entries */
}DexMapList;


typedef struct DexStringId {
    u4 stringDataOff;      /* file offset to string_data_item */
}DexStringId;

/*
 * Direct-mapped "type_id_item".
 */
typedef struct DexTypeId {
    u4  descriptorIdx;      /* index into stringIds list for type descriptor */
}DexTypeId;

/*
 * Direct-mapped "field_id_item".
 */
typedef struct DexFieldId {
    u2  classIdx;           /* index into typeIds list for defining class */
    u2  typeIdx;            /* index into typeIds for field type */
    u4  nameIdx;            /* index into stringIds for field name */
}DexFieldId;

/*
 * Direct-mapped "method_id_item".
 */
typedef struct DexMethodId {
    u2  classIdx;           /* index into typeIds list for defining class */
    u2  protoIdx;           /* index into protoIds for method prototype */
    u4    nameIdx;            /* index into stringIds for method name */
}DexMethodId;

/*
 * Direct-mapped "proto_id_item".
 */
typedef struct DexProtoId {
    u4  shortyIdx;          /* index into stringIds for shorty descriptor */
    u4  returnTypeIdx;      /* index into typeIds list for return type */
    u4  parametersOff;      /* file offset to type_list for parameter types */
} DexProtoId;

/*
 * Direct-mapped "class_def_item".
 */
typedef struct DexClassDef {
    u4  classIdx;           /* index into typeIds for this class */
    u4  accessFlags;
    u4  superclassIdx;      /* index into typeIds for superclass */
    u4  interfacesOff;      /* file offset to DexTypeList */
    u4  sourceFileIdx;      /* index into stringIds for source file name */
    u4  annotationsOff;     /* file offset to annotations_directory_item */
    u4  classDataOff;       /* file offset to class_data_item */
    u4  staticValuesOff;    /* file offset to DexEncodedArray */
}DexClassDef;


typedef struct DexFile {
    /* directly-mapped "opt" header */
    const DexOptHeader* pOptHeader;

    /* pointers to directly-mapped structs and arrays in base DEX */
    const DexHeader*    pHeader;
    const void*  pStringIds;
    const void*    pTypeIds;
    const void*   pFieldIds;
    const void*  pMethodIds;
    const void*   pProtoIds;
    const void*  pClassDefs;
    const void*  pLinkData;

    /*
     * These are mapped out of the "auxillary" section, and may not be
     * included in the file.
     */
    const void* pClassLookup;
    const void* pRegisterMapPool;       // RegisterMapClassPool

    /* points to start of DEX file data */
    const u1*   baseAddr;
    
      /* track memory overhead for auxillary structures */
    int                 overhead;

    /* additional app-specific data structures associated with the DEX */
    //void*               auxData;
  }DexFile;

typedef struct MemMapping {
    void*   addr;           /* start of data */
    size_t  length;         /* length of data */

    void*   baseAddr;       /* page-aligned base address */
    size_t  baseLength;     /* length of mapping */
}MemMapping;

typedef struct ZipArchive {
    /* open Zip archive */
    int         mFd;

    /* mapped central directory area */
    off_t       mDirectoryOffset;
    MemMapping  mDirectoryMap;

    /* number of entries in the Zip archive */
    int         mNumEntries;

    /*
     * We know how many entries are in the Zip archive, so we can have a
     * fixed-size hash table.  We probe on collisions.
     */
    int         mHashTableSize;
    void*       mHashTable;
}ZipArchive;

typedef struct RawDexFile {
    char*       cacheFileName;
    void*       pDvmDex;
}RawDexFile;

typedef struct JarFile {
    ZipArchive  archive;
    char*       cacheFileName;
    void*       pDvmDex;
}JarFile;


typedef struct DexOrJar {
    char*          fileName;
    bool           isDex;
    bool           okayToFree;
    RawDexFile*    pRawDexFile;
	  JarFile*       pJarFile;
	  u1* pDexMemory;//Android4.0��ǰ�޸��ֶΣ����ֶ����ڼ����ڴ�bytes
} DexOrJar;

//Android 4.0 �Ժ�ṹ
typedef struct DvmDex {
    /* pointer to the DexFile we're associated with */
    void *pDexFile;

    /* clone of pDexFile->pHeader (it's used frequently enough) */
    void *pHeader;

    /* interned strings; parallel to "stringIds" */
    void *pResStrings;

    /* resolved classes; parallel to "typeIds" */
    void *pResClasses;

    /* resolved methods; parallel to "methodIds" */
    void *pResMethods;

    /* resolved instance fields; parallel to "fieldIds" */
    /* (this holds both InstField and StaticField) */
    void *pResFields;

    /* interface method lookup cache */
    void *pInterfaceCache;

    /* shared memory region with file contents */
    bool                isMappedReadOnly;
    MemMapping          memMap;
}DvmDex;

//Android 4.0 ��ǰ�ṹ
typedef struct DvmDex2 {
    /* pointer to the DexFile we're associated with */
    void *pDexFile;

    /* clone of pDexFile->pHeader (it's used frequently enough) */
    void *pHeader;

    /* interned strings; parallel to "stringIds" */
    void *pResStrings;

    /* resolved classes; parallel to "typeIds" */
    void *pResClasses;

    /* resolved methods; parallel to "methodIds" */
    void *pResMethods;

    /* resolved instance fields; parallel to "fieldIds" */
    /* (this holds both InstField and StaticField) */
    void *pResFields;

    /* interface method lookup cache */
    void *pInterfaceCache;

    /* shared memory region with file contents */
    MemMapping          memMap;
}DvmDex2;

typedef struct ClassObject{
    u4               a[2];
    u4               instanceData[4];
    const char*      descriptor;
    char*            descriptorAlloc;
    u4               accessFlags;
    u4               serialNumber;
    void*            pDvmDex;
}ClassObject;

typedef struct DexProto {
    /* the class we are a part of */
    const DexFile* dexFile;
	u4             protoIdx;
}DexProto;


typedef struct Method {
    /* the class we are a part of */
    ClassObject*    clazz;
    u4              accessFlags;
    u2             methodIndex;
    u2              registersSize;  /* ins + locals */
    u2              outsSize;
    u2              insSize;
    const char*     name;
    DexProto        prototype;
    const char*     shorty;
    const u2*       insns;          /* instructions, in memory-mapped .dex */
}Method;

static jobject dump_DexFile_mCookie_DexOrJar_memMap(JNIEnv* env, jclass obj, jint cookie, jint version)
{  
    DexOrJar* pDexOrJar = (DexOrJar*) cookie;

	  int ver = version;	
	  if(ver >=14 ){
		   MemMapping memMap;
		   DvmDex* dvm_dex;
		   if(pDexOrJar->isDex){
		      if(pDexOrJar->pDexMemory == NULL){

             dvm_dex = (DvmDex*)pDexOrJar->pRawDexFile->pDvmDex;
			       memMap = dvm_dex->memMap;
             jobject byte_buffer = (*env)->NewDirectByteBuffer(env,memMap.addr, memMap.length);
             if (byte_buffer == NULL) {
                 return NULL;
             }
	           return byte_buffer;			       
			    }else{
			         DexHeader* dexHeader = (DexHeader*)pDexOrJar->pDexMemory;
			         jobject byte_buffer = (*env)->NewDirectByteBuffer(env,pDexOrJar->pDexMemory,dexHeader->fileSize);
               if(byte_buffer == NULL){
                  return NULL;
               }
	             return byte_buffer;
			    }
		   }else{

                dvm_dex = (DvmDex*)pDexOrJar->pJarFile->pDvmDex;

		        memMap = dvm_dex->memMap;
		   }
       if(dvm_dex == NULL) {
          return NULL;
       }
       jobject byte_buffer = (*env)->NewDirectByteBuffer(env,memMap.addr, memMap.length);
       if (byte_buffer == NULL) {
          return NULL;
       }
	   return byte_buffer;
	}else{
		   MemMapping memMap;
		   DvmDex2* dvm_dex;
		   if(pDexOrJar->isDex){

		      dvm_dex = (DvmDex2*)pDexOrJar->pRawDexFile->pDvmDex;
		   }else{

            dvm_dex = (DvmDex2*)pDexOrJar->pJarFile->pDvmDex;
		   }
       if(dvm_dex == NULL) {
           return NULL;
       }
       memMap = dvm_dex->memMap;
       jobject byte_buffer = (*env)->NewDirectByteBuffer(env,memMap.addr, memMap.length);
       if(byte_buffer == NULL) {
          return NULL;
       }
	   return byte_buffer;
  }
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved) 
{
	JNIEnv* env = NULL;
	jint result = -1;
	if ((*vm)->GetEnv(vm, (void**) &env, JNI_VERSION_1_4) != JNI_OK) {
		return JNI_ERR;
	}
	JNINativeMethod gMethods[] = {{ "dumpDexFileByCookie", "(II)Ljava/nio/ByteBuffer;", (void*) dump_DexFile_mCookie_DexOrJar_memMap },
	};
	jclass clazz = (*env)->FindClass(env,"com/android/reverse/util/NativeFunction");
	if (clazz == NULL) {
		return JNI_ERR;
	}
	if ((*env)->RegisterNatives(env, clazz, gMethods,
			sizeof(gMethods) / sizeof(gMethods[0])) < 0) {
		return JNI_ERR;
	}
	result = JNI_VERSION_1_4;
	return result;
}

